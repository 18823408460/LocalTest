package com.youth.banner.listener;

import android.widget.ImageView;

public interface OnLoadImageListener {
   public void OnLoadImage(ImageView view, Object url);
}